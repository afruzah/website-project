DROP DATABASE IF EXISTS `gathering`;

CREATE DATABASE `gathering`;

USE `gathering`

DROP TABLE IF EXISTS `Users`;

CREATE TABLE `Users` (
  `userID` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `Given_name` varchar(255),
  `Family_name` varchar(255),
  `Password` varchar(255),
  `Email` varchar(255)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `Events`;

CREATE TABLE `Events` (
  `eventID` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `Event_name` varchar(255),
  `Event_leaderID` int,
  `Description` varchar(300),
  `Datetime` DATETIME,
  `Members` int DEFAULT 1,
  CONSTRAINT `FK_Event_leaderID` FOREIGN KEY (`Event_leaderID`) REFERENCES `Users`(`userID`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `System_Administrators`;

CREATE TABLE `System_Administrators` (
  `adminID` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `Given_name` varchar(255),
  `Family_name` varchar(255),
  `Password` varchar(255),
  `Email` varchar(255)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `Location`;

CREATE TABLE `Location` (
  `eventID` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `StreetNo` int,
  `Street_name` varchar(255),
  `Suburb` varchar(255),
  `PostCode` varchar(255),
  `State` varchar(255)
)ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



