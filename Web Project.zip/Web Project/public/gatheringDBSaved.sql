-- MySQL dump 10.13  Distrib 8.0.28, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: gathering
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `gathering`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `gathering` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `gathering`;

--
-- Table structure for table `Events`
--

DROP TABLE IF EXISTS `Events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Events` (
  `eventID` int NOT NULL AUTO_INCREMENT,
  `Event_name` varchar(255) DEFAULT NULL,
  `Event_leaderID` int DEFAULT NULL,
  `Description` varchar(300) DEFAULT NULL,
  `Datetime` datetime DEFAULT NULL,
  `Members` int DEFAULT '1',
  PRIMARY KEY (`eventID`),
  KEY `FK_Event_leaderID` (`Event_leaderID`),
  CONSTRAINT `FK_Event_leaderID` FOREIGN KEY (`Event_leaderID`) REFERENCES `Users` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Events`
--

LOCK TABLES `Events` WRITE;
/*!40000 ALTER TABLE `Events` DISABLE KEYS */;
INSERT INTO `Events` VALUES (1,'tomorrow',1,'This is tomorrow','2022-06-11 00:00:00',1),(2,'today',1,'This is today','2022-06-16 00:00:00',1),(3,'wow',2,'This is wow','2022-06-16 00:00:00',1),(4,'fun',2,'This is fun','2022-06-16 00:00:00',1);
/*!40000 ALTER TABLE `Events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Location`
--

DROP TABLE IF EXISTS `Location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Location` (
  `eventID` int NOT NULL AUTO_INCREMENT,
  `StreetNo` int DEFAULT NULL,
  `Street_name` varchar(255) DEFAULT NULL,
  `Suburb` varchar(255) DEFAULT NULL,
  `PostCode` varchar(255) DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`eventID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Location`
--

LOCK TABLES `Location` WRITE;
/*!40000 ALTER TABLE `Location` DISABLE KEYS */;
INSERT INTO `Location` VALUES (1,1,'h','s','1','SA'),(2,96,'York','Adelaide','5000','SA'),(3,1,'1','1','1','SA'),(4,1,'1','1','1','SA');
/*!40000 ALTER TABLE `Location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `System_Administrators`
--

DROP TABLE IF EXISTS `System_Administrators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `System_Administrators` (
  `adminID` int NOT NULL AUTO_INCREMENT,
  `Given_name` varchar(255) DEFAULT NULL,
  `Family_name` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `System_Administrators`
--

LOCK TABLES `System_Administrators` WRITE;
/*!40000 ALTER TABLE `System_Administrators` DISABLE KEYS */;
INSERT INTO `System_Administrators` VALUES (1,'admin','one','$argon2i$v=19$m=4096,t=3,p=1$OIRdy5/tfNFd5CixWfXfeQ$CNJoRWkkDlSEJKe2gPDPt7IE0HY3LustNlZBe3zZYKQ','admin@mail.com'),(2,'admin','two','$argon2i$v=19$m=4096,t=3,p=1$1u5n28lZGghLgD//q/AFQA$agelK99ruG1LbaKXCSpMWod0LQ3MAY8py6UGjBj85bk','admin2@mail.com');
/*!40000 ALTER TABLE `System_Administrators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `userID` int NOT NULL AUTO_INCREMENT,
  `Given_name` varchar(255) DEFAULT NULL,
  `Family_name` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'test','one','$argon2i$v=19$m=4096,t=3,p=1$Rg+pCXZPHzSG09xPMiqfAg$axbXS58Tp65A9p8ade7u2nzq+MKK0Yq7KJsp1QFxBQ8','test@mail.com'),(2,'test','two','$argon2i$v=19$m=4096,t=3,p=1$r4vfqehjeHC7DbytpJeXcg$m9V2tNsp8hqsYZK+nZ0FWy/i3wL3TGZCAQk6G5xvRJY','test2@mail.com');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-10 10:08:26

/*

Insert INTO Users (given_name,family_name,password,email) VALUES (?,?,?,?);

SELECT email, password from Users;

INSERT INTO System_Administrators(given_name,family_name,password,email) VALUES (?,?,?,?);

SELECT email, password from Users;

UPDATE ? SET ? = ? where ? = ?;

SELECT adminID FROM System_Administrators WHERE useradminID = LAST_INSERT_ID();

SELECT adminID, password FROM System_Administrators WHERE email = ? ;

SELECT * FROM Users;

SELECT * FROM Events;

SELECT * FROM System_Administrators;
*/