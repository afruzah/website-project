DROP DATABASE IF EXISTS `gathering`;

CREATE DATABASE `gathering`;

USE `gathering`;

CREATE TABLE `Users` (
  `Username` varchar(255) PRIMARY KEY,
  `Given_name` varchar(255),
  `Family_name` varchar(255),
  `Password` varchar(255),
  `Email` varchar(255),
);

CREATE TABLE `Login` (
  `Username` varchar(255) PRIMARY KEY,
  `Password` varchar(255),
  `Datetime` datetime
);

CREATE TABLE `Admin_Login` (
  `Admin_Username` varchar(255) PRIMARY KEY,
  `Password` varchar(255),
  `Datetime` datetime
);

CREATE TABLE `Events` (
  `Group_name` varchar(255) PRIMARY KEY,
  `Event_name` varchar(255),
  `Date` datetime,
  `Location` varchar(255)
);

CREATE TABLE `Groups` (
  `Group_name` varchar(255) PRIMARY KEY,
  `Group_leader` varchar(255),
  `Username` varchar(255)
);

CREATE TABLE `Locations` (
  `Event_name` varchar(255),
  `Address` varchar(255),
  `Telephone` varchar(255),
  `Group_name` varchar(255) PRIMARY KEY
);

CREATE TABLE `System_Administrators` (
  `Admin_Username` varchar(255) PRIMARY KEY,
  `Given_name` varchar(255),
  `Family_name` varchar(255),
  `Password` varchar(255),
  `Email` varchar(255),
  `Mobile_no` varchar(255)
);

CREATE TABLE `Website_Problems` (
  `Admin_Username` varchar(255) PRIMARY KEY,
  `Username` varchar(255),
  `Event_name` varchar(255),
  `Group_name` varchar(255),
  `Address` varchar(255)
);

CREATE TABLE `Usergroup` (
  `Group_name` varchar(255) PRIMARY KEY,
  `Group_leader` varchar(255),
  `Username` varchar(255)
);

ALTER TABLE `Groups` ADD FOREIGN KEY (`Group_name`) REFERENCES `Events` (`Group_name`);

ALTER TABLE `Users` ADD FOREIGN KEY (`Username`) REFERENCES `Usergroup` (`Group_name`);

ALTER TABLE `Locations` ADD FOREIGN KEY (`Group_name`) REFERENCES `Events` (`Group_name`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Username`) REFERENCES `System_Administrators` (`Admin_Username`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Event_name`) REFERENCES `System_Administrators` (`Admin_Username`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Group_name`) REFERENCES `System_Administrators` (`Admin_Username`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Address`) REFERENCES `System_Administrators` (`Admin_Username`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Username`) REFERENCES `Users` (`Username`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Event_name`) REFERENCES `Events` (`Event_name`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Group_name`) REFERENCES `Groups` (`Group_name`);

ALTER TABLE `Website_Problems` ADD FOREIGN KEY (`Address`) REFERENCES `Locations` (`Group_name`);

ALTER TABLE `Usergroup` ADD FOREIGN KEY (`Group_name`) REFERENCES `Groups` (`Group_name`);

ALTER TABLE `Login` ADD FOREIGN KEY (`Username`) REFERENCES `Users` (`Username`);

ALTER TABLE `Admin_Login` ADD FOREIGN KEY (`Admin_Username`) REFERENCES `System_Administrators` (`Admin_Username`);

ALTER TABLE `System_Administrators` ADD FOREIGN KEY (`Given_name`) REFERENCES `System_Administrators` (`Admin_Username`);
