var eventData = new Vue({
	el: "#eventDetails",
	data: {
		eventName: "Beach Event",
		host: "Sam",
		maxGuest: 50,
		guest: 14,
		address: "City - Area - street",
		date: "20/5/2022 - 6:00 pm",
	}
});