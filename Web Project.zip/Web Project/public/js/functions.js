function signin(){
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){
            window.location.replace("../user.html");
            alert("login successful!");
        }
    };
    xhttp.open("POST", "/login", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({email:email, password: password}));
}


function signup(){
  let givenname = document.getElementById("givenname").value;
  let familyname = document.getElementById("familyname").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){
           window.location.assign("../user.html");
           alert("welcome to gathering");
        }
    };
    xhttp.open("POST", "/register-user", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({givenname: givenname, familyname: familyname, email: email, password: password}));
}




function navigation() {
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var data = JSON.parse(this.responseText);
        if (data == 1) {
          document.getElementById("home").href = "user.html";
          document.getElementById("home").innerText = "Profile";
          document.getElementById("system").href = "/logout";
          document.getElementById("system").innerText = "Sign Out";
        }else if (data == 2) {
          document.getElementById("home").href = "administrators.html";
          document.getElementById("home").innerText = "Admin";
          document.getElementById("system").href = "/logout";
          document.getElementById("system").innerText = "Sign Out";
        }
      }
  };


  xhttp.open("GET", "/session", true);
  xhttp.send();
}
window.onload = navigation;

function create() {
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var data = JSON.parse(this.responseText);
        if (data == 0) {
          window.location.replace("../sign-up.html");
          alert("Make an account to create an event");
        } else {
          navigation();
        }
      }
  };


  xhttp.open("GET", "/session", true);
  xhttp.send();
}

function makeEvent(){
  let eventname = document.getElementById("eventname").value;
  let streetno = document.getElementById("streetno").value;
  let streetname = document.getElementById("streetname").value;
  let suburb = document.getElementById("suburb").value;
  let postcode = document.getElementById("postcode").value;
  let state = document.getElementById("state").value;
  let date = document.getElementById("datetime").value;
  let description = document.getElementById("description").value;
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){
            window.location.replace("../user.html");
            alert("You've made an event!");
        }
    };
    xhttp.open("POST", "/addEvent", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({eventname: eventname, streetno: streetno, streetname: streetname, suburb: suburb, postcode: postcode, state: state, date: date, description: description}));
}

function notLogged(){
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var data = JSON.parse(this.responseText);
      if (data !== 1) {
        window.location.replace("../index.html");
        alert("Make an account");
      } else {
        navigation();
      }
    }
};

xhttp.open("GET", "/session", true);
xhttp.send();
}

function hideButtons() {

  let button1 = document.getElementsByClassName("sign-button")[0];
  let button2 = document.getElementsByClassName("sign-button")[1];

  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        var data = JSON.parse(this.responseText);
        if (data !== 0) {
          button1.style.visibility="hidden";
          button2.style.visibility="hidden";
        }
      }
  };

  xhttp.open("GET", "/session", true);
  xhttp.send();
}


function adminSignUp(){
  let givenname = document.getElementById("givenname").value;
  let familyname = document.getElementById("familyname").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){
           window.location.assign("../administrators.html");
        }
    };
    xhttp.open("POST", "/adminsignup", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({givenname: givenname, familyname: familyname, email: email, password: password}));
}

function adminSignIn(){
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
      let xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function(){
        if(this.readyState == 4 && this.status ==200){
          window.location.replace("../administrators.html");
          alert("login successful!");
        }
    };
    xhttp.open("POST", "/adminsignin", true);
    xhttp.setRequestHeader("Content-type", "application/json");
    xhttp.send(JSON.stringify({email:email, password: password}));
}

function authorise(){
  var xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var data = JSON.parse(this.responseText);
      if (data !== 2) {
        window.location.replace("../index.html");
        alert("Unauthorised");
      } else {
        navigation();
      }
    }
};

xhttp.open("GET", "/session", true);
xhttp.send();
}

//admin functions
function updates(){

  let tablename = document.getElementById("tablename").value;

  let uniqueidcolumn =document.getElementById("uniqueidcolumn").value;
  let uniqueid = document.getElementById("uniqueid").value;

  let columnname = document.getElementById("columnname").value;

  let newdata = document.getElementById("newdata").value;


   let xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function(){
     if(this.readyState == 4 && this.status ==200){
     // document.getElementById("date").innerHTML = this.responseText;
       alert("update successful!");

     }
 };
 xhttp.open("POST", "/updates");
 xhttp.setRequestHeader("Content-type","application/JSON");
 xhttp.send(JSON.stringify({tablename: tablename, uniqueidcolumn: uniqueidcolumn, uniqueid: uniqueid, columnname: columnname, newdata:newdata}));
}

function usersshowinfo(){
   let xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function(){
     if(this.readyState == 4 && this.status ==200){
     // document.getElementById("date").innerHTML = this.responseText;
       //console.log(this.responseText)
       var contents = JSON.parse(this.responseText);
       for (var i=0;i<contents.length;i++){
         //console.log(actors[i])
         var trTag= document.createElement('tr');
         var tdTagUserID= document.createElement('td');
         var tdTagGivenName= document.createElement('td');
         var tdTagFamilyName= document.createElement('td');

         var tdTagPassword= document.createElement('td');
         var tdTagEmail= document.createElement('td');
         tdTagUserID.innerText= contents[i].userID;
         tdTagGivenName.innerText= contents[i].Given_name;
         tdTagFamilyName.innerText= contents[i].Family_name;
         tdTagPassword.innerText= contents[i].Password;
         tdTagEmail.innerText= contents[i].Email;
         trTag.appendChild(tdTagUserID);
         trTag.appendChild(tdTagGivenName);
         trTag.appendChild(tdTagFamilyName);
         trTag.appendChild(tdTagPassword);
         trTag.appendChild(tdTagEmail);
         document.getElementsByTagName('tbody')[0].appendChild(trTag);
       }

     }
 };
 xhttp.open("GET", "/userstable");
 xhttp.send();
}

function eventsshowinfo(){
   let xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function(){
     if(this.readyState == 4 && this.status ==200){
     // document.getElementById("date").innerHTML = this.responseText;
       //console.log(this.responseText)
       var contents = JSON.parse(this.responseText);
       for (var i=0;i<contents.length;i++){
         //console.log(actors[i])
         var trTag= document.createElement('tr');
         var tdTageventid= document.createElement('td');
         var tdTagEventName= document.createElement('td');
         var tdTageventleaderid = document.createElement('td');

         var tdTagDescription= document.createElement('td');
         var tdTagDatetime= document.createElement('td');
         tdTageventid.innerText= contents[i].eventID;
         tdTagEventName.innerText= contents[i].Event_name;
         tdTageventleaderid.innerText= contents[i].Event_leader_ID;
         tdTagDescription.innerText= contents[i].Description;
         tdTagDatetime.innerText= contents[i].Datetime;
         trTag.appendChild(tdTageventid);
         trTag.appendChild(tdTagEventName);
         trTag.appendChild(tdTageventleaderid);
         trTag.appendChild(tdTagDescription);
         trTag.appendChild(tdTagDatetime);
         document.getElementsByTagName('tbody')[0].appendChild(trTag);
       }

     }
 };
 xhttp.open("GET", "/eventstable");
 xhttp.send();
}

function adminshowinfo(){
   let xhttp = new XMLHttpRequest();
   xhttp.onreadystatechange = function(){
     if(this.readyState == 4 && this.status ==200){
     // document.getElementById("date").innerHTML = this.responseText;
       //console.log(this.responseText)
       var contents = JSON.parse(this.responseText);
       for (var i=0;i<contents.length;i++){
         //console.log(actors[i])
         var trTag= document.createElement('tr');
         var tdTagUserID= document.createElement('td');
         var tdTagGivenName= document.createElement('td');
         var tdTagFamilyName= document.createElement('td');

         var tdTagPassword= document.createElement('td');
         var tdTagEmail= document.createElement('td');
         tdTagUserID.innerText= contents[i].adminID;
         tdTagGivenName.innerText= contents[i].Given_name;
         tdTagFamilyName.innerText= contents[i].Family_name;
         tdTagPassword.innerText= contents[i].Password;
         tdTagEmail.innerText= contents[i].Email;
         trTag.appendChild(tdTagUserID);
         trTag.appendChild(tdTagGivenName);
         trTag.appendChild(tdTagFamilyName);
         trTag.appendChild(tdTagPassword);
         trTag.appendChild(tdTagEmail);
         document.getElementsByTagName('tbody')[0].appendChild(trTag);
       }

     }
 };
 xhttp.open("GET", "/admintable");
 xhttp.send();
}

function showProfile(){
    let xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function ()
    {

        if (this.readyState == 4 && this.status == 200){
            var response = JSON.parse(this.responseText);
            document.getElementById("username").innerText ="Hello " + response.name + " " + response.family;
            document.getElementById("useremail").innerText = "Email: " + response.email;

        } else if (this.readyState == 4 && this.status >= 400){
            alert("You're not logged in!");
            window.location.assign("../index.html");
        }
    };

    xhttp.open("GET", "/userData", true);
    xhttp.send();
}

function popularEvents(){
  let xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function ()
  {

      if (this.readyState == 4 && this.status == 200){
          var response = JSON.parse(this.responseText);
          document.getElementById("eventname").innerText = response[0].Event_name;
          document.getElementById("eventname2").innerText = response[1].Event_name;
          document.getElementById("eventnum").innerText = "Joined: " + response[0].Members;
          document.getElementById("eventtnum2").innerText = "Joined: " + response[1].Members;
          let desc1 = response[0].Description;
          let desc2 = response[1].Description;
          if(desc1.length > 50) {
            desc1 = desc1.substring(0,50);
          }
          if(desc2.length > 50) {
            desc2 = desc2.substring(0,50);
          }
          document.getElementById("eventdesc").innerText = desc1;
          document.getElementById("eventdesc2").innerText = desc2;
      }
  };

  xhttp.open("GET", "/popularEvents", true);
  xhttp.send();
}

function suggestedEvents(){
  let xhttp = new XMLHttpRequest();

  xhttp.onreadystatechange = function ()
  {

      if (this.readyState == 4 && this.status == 200){
          var response = JSON.parse(this.responseText);
          document.getElementById("suggestname").innerText = response[0].Event_name;
          document.getElementById("suggestname2").innerText = response[1].Event_name;
          document.getElementById("suggestnum").innerText = "Joined: " + response[0].Members;
          document.getElementById("suggestnum2").innerText = "Joined: " + response[1].Members;
          let desc1 = response[0].Description;
          let desc2 = response[1].Description;
          if(desc1.length > 50) {
            desc1 = desc1.substring(0,50);
          }
          if(desc2.length > 50) {
            desc2 = desc2.substring(0,50);
          }
          document.getElementById("suggestdesc").innerText = desc1;
          document.getElementById("suggestdesc2").innerText = desc2;
      }
  };

  xhttp.open("GET", "/suggestedEvents");
  xhttp.send();
}


function loadUser() {
    navigation();
    showProfile();
    suggestedEvents();
    popularEvents();
}

