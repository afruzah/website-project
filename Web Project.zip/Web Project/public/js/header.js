var eventData = new Vue({
	el: "#header",
	data: {
		websiteName: "GATHERING",
		top_menu: [{ title:'Home',         url:'home.html' },
				  { title:'Create Event',        url:'#' },
				  { title:'About',        url:'#' },
				  { title:'FAQ',        url:'#' }],
	}
});