module.exports = {
    /*
     * This file contains the configurations information of Twitter login app.
     * It consists of Twitter app information, database information.
     */

    facebook_api_key: "535129358107255",
    facebook_api_secret: "0a7f70b391d5504fae5922ee1d2f5090",
    callback_url: "https://afruzah-code50-64880398-wr75qjgj6354v5-3000.githubpreview.dev/",
    use_database: true,
    host: "127.0.0.1",
    database: "gathering"
  };