var express = require('express');
var router = express.Router();
var argon2 = require('argon2');
var session = require('express-session');
const CLIENT_ID = '128754824437-mvsbrt19aqhomm8opj7svpauvu9ffluk.apps.googleusercontent.com';
const {OAuth2Client} = require('google-auth-library');
const client = new OAuth2Client(CLIENT_ID);

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index.html');
});

var hash = "" ;
router.post('/register-user', async function(req, res, next) {
  console.log(req.body)
  console.log("check", req.body.givenname, req.body.familyname, req.body.email, req.body.password);
    if( 'givenname' in req.body &&
        'familyname' in req.body &&
        'email' in req.body &&
        'password' in req.body) {

        hash = await argon2.hash(req.body.password);
        console.log(hash);

        req.pool.getConnection( function(err,connection) {
            if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
            }
            var query = `INSERT INTO Users(given_name,family_name,email,password)
                            VALUES (?,?,?,?);`;
            connection.query(query,[
                req.body.givenname,
                req.body.familyname,
                req.body.email,
                hash], function(err, rows, fields) {
                  connection.release(); // release connection
                  if (err) {
                    console.log(err);
                    res.sendStatus(500);
                    return;
                  } let query = "SELECT userID, Given_name, Family_name, Email FROM Users WHERE email = ?;";
                  connection.query(query, [req.body.email], function(error, rows, fields) {
                      connection.release();
                      if (error) {
                          console.log(error);
                          res.sendStatus(500);
                          return;
                      }
                      req.session.user = rows[0];
                      req.session.save();
                      res.sendStatus(200);
                  });
            });
        });

    } else {
      console.log("err");
        res.sendStatus(400);
    }
});

router.post('/login', function(req, res, next) {

  if( 'email' in req.body &&
      'password' in req.body) {


        req.pool.getConnection( function(err,connection) {
            if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
            };
            var query = `SELECT userID, password, Given_name, Family_name, Email
                            FROM Users WHERE email = ?`;

            connection.query(query,[req.body.email], async function(err, rows, fields) {
              connection.release(); // release connection
              if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
              }
              if(rows.length > 0){

                  let valid = await argon2.verify(rows[0].password, req.body.password);

                  if (valid) {
                      delete rows[0].password;
                      req.session.user = rows[0];
                      req.session.save();
                      res.end();
                  } else {
                      res.sendStatus(401)
                  }

              } else {
                  res.sendStatus(401);
              }
            });

          });

    }
  else {
      res.sendStatus(400);
  }
});

router.get('/logout', function(req, res, next) {
  delete req.session.user;
  req.session.admin = false;
  bool = 0;
  res.redirect('/');
});

router.get('/eventData', function(req, res, next) {

  req.pool.getConnection( function(err,connection) {
      if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
      }
      var query = `SELECT * FROM Events INNER JOIN Location
                    ON Events.eventID = Location.eventID;`;
          connection.query(query,function(err, rows, fields) {
            connection.release(); // release connection
        if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
        }
        res.json(rows);
      });
  });
});


router.post('/addEvent', function(req, res, next) {
  if( 'eventname' in req.body &&
        'date' in req.body &&
        'streetno' in req.body &&
        'streetname' in req.body &&
        'suburb' in req.body &&
        'postcode' in req.body &&
        'state' in req.body &&
        'description' in req.body ) {

    req.pool.getConnection( function(err,connection) {
        if (err) {
            console.log(err);
            res.sendStatus(500);
            return;
        }
        let user = req.session.user.userID;

        var query = `INSERT INTO Events (Event_name,Event_leaderID, Description, Datetime)
                        VALUES (?, ?,?,?);`;

        connection.query(query,[
            req.body.eventname,
            user,
            req.body.description,
            req.body.date], function(err, rows, fields) {
          connection.release(); // release connection
          if (err) {
            console.log(err);
            res.sendStatus(500);
            return;
          }
          res.end();
        });
    });
    req.pool.getConnection( function(err,connection) {
      if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
      }
      var query = `INSERT INTO Location (StreetNo,Street_name, Suburb, PostCode, State)
                      VALUES (?,?,?,?,?);`;
      connection.query(query,[
          req.body.streetno,
          req.body.streetname,
          req.body.suburb,
          req.body.postcode,
          req.body.state], function(err, rows, fields) {
        connection.release(); // release connection
        if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
        }
        res.end();
      });
  });

  } else {
    res.sendStatus(400);
  }

});

let bool = 0;
router.get('/session', function(req, res){

  let session = req.session.user;
  if (session!==undefined) {
    bool = 1;
  }
  if (req.session.admin==true) {
    bool = 2;
  }
  console.log(bool);
  res.json(bool);
});

router.post('/adminsignup', async function(req, res, next) {
  console.log(req.body);
  console.log("check", req.body.givenname, req.body.familyname, req.body.email, req.body.password);
    if( 'givenname' in req.body &&
        'familyname' in req.body &&
        'email' in req.body &&
        'password' in req.body) {

        hash = await argon2.hash(req.body.password);
        console.log(hash);

        req.pool.getConnection( function(err,connection) {
            if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
            }
            var query = `INSERT INTO System_Administrators(given_name,family_name,email,password)
                            VALUES (?,?,?,?);`;
            connection.query(query,[
                req.body.givenname,
                req.body.familyname,
                req.body.email,
                hash], function(err, rows, fields) {
                  connection.release(); // release connection
                  if (err) {
                    console.log(err);
                    res.sendStatus(500);
                    return;
                  } let query = "SELECT adminID FROM System_Administrators WHERE Email = ?;";
                  connection.query(query, [req.body.email], function(error, rows, fields) {
                      connection.release();
                      if (error) {
                          console.log(error);
                          res.sendStatus(500);
                          return;
                      }
                      req.session.user = "admin"+rows[0];
                      req.session.admin = true;
                      req.session.save();
                      res.sendStatus(200);
                  });

            });
        });

    } else {
      console.log("err");
        res.sendStatus(400);
    }
});

router.post('/adminsignin', function(req, res, next) {

  if( 'email' in req.body &&
      'password' in req.body) {


        req.pool.getConnection( function(err,connection) {
            if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
            };
            var query = "SELECT adminID, password FROM System_Administrators WHERE email = ?";

            connection.query(query,[req.body.email], async function(err, rows, fields) {
              connection.release(); // release connection
              if (err) {
                console.log(err);
                res.sendStatus(500);
                return;
              }
              if(rows.length > 0){

                  let valid = await argon2.verify(rows[0].password, req.body.password);

                  if (valid) {
                      delete rows[0].password;
                      req.session.user = "admin"+rows[0];
                      req.session.admin = true;
                      req.session.save();
                      res.json(rows[0]);
                  } else {
                      return res.sendStatus(401)
                  }

              } else {
                  res.sendStatus(401);
              }
            });

          });

    }
  else {
      res.sendStatus(400);
  }
});


router.post("/updates", function (req, res) {
  // get data from forms and add to the table



    req.pool.getConnection( function(err,connection) {
      if (err) {
          console.log(err);
          res.sendStatus(500);
          return;
      }


  var query = "UPDATE ? SET ? = ? where ? = ? ;";

  connection.query(query, [req.body.tablename, req.body.columnname, req.body.newdata, req.body.uniqueid, req.body.uniqueidcolumn, req.body.uniqueid], function (err, result) {
    if (err) {
      // Throw your error output here.
      console.log("An error occurred.");
      res.send("Error");
    } else {
      // Throw a success message here.
      console.log("1 record successfully updated into db");
    }

  });
});
  });
router.get('/userstable', function(req, res){
  req.pool.getConnection(function(err, connection){
    if(err){
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var query = "SELECT * FROM Users;";
    connection.query(query, function(err, rows, fields){

      if (err){
        console.log(err);
        res.sendStatus(500);
        return;
      }
      res.send(rows);
      connection.release();
    });
  });
});

router.get('/eventstable', function(req, res){
  req.pool.getConnection(function(err, connection){
    if(err){
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var query = "SELECT * FROM Events;";
    connection.query(query, function(err, rows, fields){

      if (err){
        console.log(err);
        res.sendStatus(500);
        return;
      }
      res.send(rows);
      connection.release();
    });
  });
});

router.get('/admintable', function(req, res){
  req.pool.getConnection(function(err, connection){
    if(err){
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var query = "SELECT * FROM System_Administrators;";
    connection.query(query, function(err, rows, fields){

      if (err){
        console.log(err);
        res.sendStatus(500);
        return;
      }
      res.send(rows);
      connection.release();
    });
  });
});

//get info data
router.get('/userData', function(req, res, next) {
  if (req.session.user) {
    let toSend = {name: req.session.user.Given_name, family: req.session.user.Family_name, email: req.session.user.Email};
    console.log(req.session.user);
    res.send(toSend);
  } else {
      res.sendStatus(403);
      return;
  }
});

router.get('/popularEvents', function(req, res){
  req.pool.getConnection(function(err, connection){
    if(err){
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var query = `SELECT * FROM Events ORDER BY eventID DESC LIMIT 2;`;
    connection.query(query, function(err, rows, fields){

      if (err){
        console.log(err);
        res.sendStatus(500);
        return;
      }
      res.send(rows);
      connection.release();
    });
  });
});

router.get('/suggestedEvents', function(req, res){
  req.pool.getConnection(function(err, connection){
    if(err){
      console.log(err);
      res.sendStatus(500);
      return;
    }
    var query = `SELECT * FROM Events ORDER BY eventID ASC LIMIT 2;`;
    connection.query(query, function(err, rows, fields){

      if (err){
        console.log(err);
        res.sendStatus(500);
        return;
      }
      res.send(rows);
      connection.release();
    });
  });
});




module.exports = router;
