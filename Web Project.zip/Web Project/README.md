Please install the libraries that are required in app.js, they were saved on creation so this might not be necessary
Currently on the website users and administrators can login on separate pages. The admin login link is a discrete button on the footer of the index page.
There are 2 admins in the database, admin@mail.com and admin2@mail.com The password for admin@mail.com is admin and the password for admin2@mail.com is admin2. The users in the database follow this pattern also. The users that are in the database are test@mail.com where the password is test and test2@mail.com where the password is test2.
The login page can be a bit buggy, the window might not redirect you to your necessary page even though you will actually be logged in. I recommend refreshing the page.
Events can be created on the website, the create event link is found in the nav menu which is a button on the top right.
The events update the database but currently there is no function to search for these events or manage availability.
APIs have not been added to this website, they are confusing :(
